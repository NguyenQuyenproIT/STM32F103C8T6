#include "stm32f10x.h"                  // Device header
#include "stm32f10x_adc.h"              // Keil::Device:StdPeriph Drivers:ADC
#include "stm32f10x_gpio.h"             // Keil::Device:StdPeriph Drivers:GPIO
#include "mcu-i2c.h"
#include "sensor_pcf8574.h"
#include "stdio.h"
#include "math.h"


void delay_ms(uint16_t time);
void ADC_Config(void);
void GPIO_Config(void);
void Buzzer(int ppm);
uint16_t Read_ADC(void);
float find_Rs(float voltage);
float find_PPM(float Rs);
float Convert_ADC_To_Voltage(uint16_t adc_value);
void Display_LCD(int ppm);
		
	
	
#define VREF 3.3
#define VMQ2 5
#define ADC_MAX 4095 // gia tri chuyen doi max
#define RL 10000 // resistance RL is dien tro tai? ~ default
#define R0 10000  // can get approximate value = tuong doi (theo datasheet)
 
#define M -0.455
#define B 1.24

#define GAS_THRESHOLD 200


void delay_ms(uint16_t time)
{
	uint16_t i;
	for( i = 0; i < time; i++){
		SysTick -> CTRL  |= 0x00000005;
		SysTick -> LOAD   = 72000 - 1; 
		SysTick -> VAL    = 0;
		while(!(SysTick -> CTRL & (1 << 16))){
		}
	}
}

void ADC_Config(){  
	GPIO_InitTypeDef GPIO_InitStructure; // cau hinh chan GPIO
	ADC_InitTypeDef ADC_InitStructure;	 // cau hinh ADC
	
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); // bat xung clock cho ADC1
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // bat xung clock cho portA
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; // (PA0-ADC-channel-0)
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN; // mode Analog INput(doc analog signal (voltage)
			GPIO_Init(GPIOA, &GPIO_InitStructure);  // goi ham khoi tao pin, mode
		
		ADC_InitStructure.ADC_Mode = ADC_Mode_Independent; // hoat dong rieng biet, khong dong bo voi ADC khac
		ADC_InitStructure.ADC_ScanConvMode = DISABLE; // khong quet nhieu kenh, chi doc 1 kenh(channel 0)
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE; // Che do chuyen doi lien tuc: ADC tu chuyen doi lien tuc sau khi enable
		ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None; // khong dung ngat ngoai, kich hoat chuyen doi, dung software
		ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right; // dich bit return value, gia tri 12 bit nam o 12 bit thap cua register 16 bit
		ADC_InitStructure.ADC_NbrOfChannel = 1; // so luong kenh can chuyen doi la 1
		ADC_Init(ADC1, &ADC_InitStructure); // Goi ham khoi tao ADC1 da thiet lap

		ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_55Cycles5); // similar PA0, do uu tien so 1)
//																																thoi gian lay mau 55.5 chu ky ADC(cham vua phai, cho tin hieu on dinh)
		ADC_Cmd(ADC1, ENABLE); // turn on ADC1
		// reset va hieu chinh ADC, giup nang cao do chinh x�c, bat buoc sau khi bat ADC lan dau
		ADC_ResetCalibration(ADC1); 
		while(ADC_GetResetCalibrationStatus(ADC1)); 
		ADC_StartCalibration(ADC1);
		while(ADC_GetCalibrationStatus(ADC1));
		
		ADC_SoftwareStartConvCmd(ADC1, ENABLE); // bat dau chuyen doi equal software, neu mode lien tuc thi no se tu chuyen doi
}
		
uint16_t Read_ADC() {
			ADC_SoftwareStartConvCmd(ADC1, ENABLE); // goi lenh khoi tao ADC
			while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC)); // EOC duoc set, qua trinh chuyen doi hoan thanh -> DR co gia tri sa~n
			return ADC_GetConversionValue(ADC1); // doc va tra ve gia tri 12 bit tu thanh ghi ADC
	}	// (ADC1 -> DR) data register: luu ket qua 12 bit cua qua trinh ADC
		// copy v�o variable in RAM
		
float Convert_ADC_To_Voltage(uint16_t adc_value) { // chuyen doi gia tri ADC tu(0-4095) become (0-VREF)
				return ((float)adc_value / ADC_MAX) * VREF;
		}
		
		
		void GPIO_Config(){
				GPIO_InitTypeDef GPIO_InitStructure;

				RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

				GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
				GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
				GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
				GPIO_Init(GPIOB, &GPIO_InitStructure);
			
				GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
				GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
				GPIO_Init(GPIOB, &GPIO_InitStructure);
			
		}
				
	void check_Buzzer(int *ppm){
				if (*ppm > GAS_THRESHOLD) {
						GPIO_SetBits(GPIOB, GPIO_Pin_8);
				} else {
						GPIO_ResetBits(GPIOB, GPIO_Pin_8);
				}

				if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9) == 0) {
						*ppm = 0;
						Display_LCD(*ppm);  
						GPIO_ResetBits(GPIOB, GPIO_Pin_8);
						while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9) == 0);
				}
		}


		float find_Rs(float voltage) {
				return RL * ((VREF - voltage) / voltage);	
		}

		float find_PPM(float Rs) {
			float Rs_R0;
				if (Rs <= 0) return 0;
				 Rs_R0 = Rs/R0;
				return (int)pow(10, (log10(Rs_R0) - B) / M);
		}

		

void Display_LCD(int ppm) {
    char buffer[16];

    PCF_Clear(); 
    PCF_Goto(1, 0);  
    sprintf(buffer, "PPM Value: %d", ppm);  
    PCF_Print(buffer); 

    PCF_Goto(2, 0);  
    if(ppm > GAS_THRESHOLD) { 
        PCF_Print("Warning!");  
    }
		else{
        PCF_Print("Safe!");  
    }
}

int main(){
	I2Cx_Init(I2C1, I2C1_B67, 100000);
	ADC_Config();
	GPIO_Config();
		PCF_Init(); 
		PCF_Clear();

	while(1){ 
    uint16_t adc_value = Read_ADC(); // gia tri sau khi chuyen doi ADC
    float voltage = Convert_ADC_To_Voltage(adc_value);
    float Rs = find_Rs(voltage);
    int ppm = find_PPM(Rs);
		check_Buzzer(&ppm); 
    Display_LCD(ppm);  
    Delay_ms(300);    
		}
}